class Solution:
    def getSum(self, a, b):
        """
        :type a: int
        :type b: int
        :rtype: int
        """
        return a + b






    """
        Time Complexity = O(1)
        Space Complexity = O(1)

        Calculate the sum of two integers a and b, but you are not allowed to use the operator + and -.

        Example:
        Input: a = -2, b = 3
        Output: 1
    """
